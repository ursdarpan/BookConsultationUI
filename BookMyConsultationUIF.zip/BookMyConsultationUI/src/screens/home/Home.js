/* eslint-disable linebreak-style */
/* eslint-disable react/jsx-filename-extension */
/* eslint-disable react/function-component-definition */
import React from 'react';
import Header from '../../common/header/Header';
import HomeTabs from './HomeTabs';

export default function Home() {
  return (
    <div>
      <Header />
      <HomeTabs />
    </div>
  );
}
