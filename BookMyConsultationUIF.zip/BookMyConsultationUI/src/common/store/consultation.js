/* eslint-disable default-param-last */
import { createStore } from 'redux';

const initialState = {
  userDetails: [],
};

function consultationReducer(state = initialState, action) {
  switch (action.type) {
    case 'SET_USER_DETAILS':
      return { ...state, userDetails: action.payload };
      // Object.assign(state.userDetails, action.payload);
      // console.log(state);
      // return { ...state };
    default:
      return state;
  }
}

export default createStore(consultationReducer);
